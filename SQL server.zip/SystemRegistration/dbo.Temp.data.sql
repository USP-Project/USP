﻿INSERT INTO [dbo].[Temp] ([ID], [Name], [Last], [Dates]) VALUES (4, N'Vanyo', N'Popazov', N'2020-04-07')
INSERT INTO [dbo].[Temp] ([ID], [Name], [Last], [Dates], [Time]) VALUES (5, N'Presiyan', N'Tigara', N'2020-04-22', N'11:52')
