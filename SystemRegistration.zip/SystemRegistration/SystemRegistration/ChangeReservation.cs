﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SystemRegistration
{
    public partial class ChangeReservation : Form
    {
        string gender = "";
        public ChangeReservation()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                gender = "Boy";

            }
            else if (radioButton2.Checked == true)
            {
                gender = "Girl";

            }

            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Vanyo\\Documents\\Data.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Temp SET ID = '" + textBox1.Text + "' , Name = '" + textBox2.Text + "' , Last ='" + textBox3.Text + "', Dates ='" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "', Time ='" + dateTimePicker2.Value.ToString("hh:mm") + "', Gender ='" + gender +  "', WHERE ID = " + textBox1.Text + "')", con) ;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void ChangeReservation_Load(object sender, EventArgs e)
        {

        }
    }
}
