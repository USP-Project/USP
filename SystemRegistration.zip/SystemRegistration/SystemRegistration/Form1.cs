﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SystemRegistration
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] usernames = { "admin1", "vanyo2", "presiyan3", "nikola4" };
        string[] passwords = { "password1", "password2", "password3", "password4" };
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (usernames.Contains(textBox1.Text) && passwords.Contains(textBox2.Text) && Array.IndexOf(usernames,textBox1.Text) == Array.IndexOf(passwords,textBox2.Text))
            {
                Main ss = new Main();
                ss.Show();

                MessageBox.Show("Logged in sucessfully");
            }
            else
            {

                MessageBox.Show("Logging was unsuccessful! Please check your username or password again!");
            }

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Authors ss = new Authors();
            ss.Show();
        }
    }
}
